package cardealder.service.api;

import javax.xml.bind.JAXBException;

public interface Service {

    void seed() throws JAXBException;

}
