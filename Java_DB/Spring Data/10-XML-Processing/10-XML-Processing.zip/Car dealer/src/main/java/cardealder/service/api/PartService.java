package cardealder.service.api;

public interface PartService extends Service  {
}
