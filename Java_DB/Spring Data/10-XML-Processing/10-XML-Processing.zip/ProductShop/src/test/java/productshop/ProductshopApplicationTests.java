package productshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductshopApplicationTests {

    @Test
    void contextLoads() {
    }

}
